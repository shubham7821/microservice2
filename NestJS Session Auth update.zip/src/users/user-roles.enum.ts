export enum UserRoles {
    User1 = 'user1',
    User2 = 'user2',
    Admin = 'admin',
  }
  