import { Injectable, NotFoundException } from '@nestjs/common';
import { UsersService } from 'src/users/users.service';
import * as bcrypt from 'bcrypt';


@Injectable()
export class AuthService {
  constructor(private readonly usersService: UsersService) {}

  // Validate a user
  async validateUser(username: string, password: string): Promise<any> {
    const user: any = await this.usersService.getUser(username); // Use type assertion

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const passwordValid = await bcrypt.compare(password, user.password);

    if (!passwordValid) {
      return null;
    }

    return {
      userId: user.id,
      userName: user.username
    };
  }
}
