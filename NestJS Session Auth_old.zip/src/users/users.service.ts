import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User } from './users.model';

@Injectable()
export class UsersService {
  getUser(username: string) {
    throw new Error('Method not implemented.');
  }
  constructor(@InjectModel('user') private readonly userModel: Model<User>) {}
 
  // Signup user method with username, email, and password
  async insertUser(username: string, email: string, password: string): Promise<User> {
    const newUser = new this.userModel({
      username: username.toLowerCase(),
      email: email.toLowerCase(), // Ensure email is stored in lowercase for consistency
      password,
    });
    return await newUser.save();
  }
  
  // Log in user using the findOne method
  async getUserByEmail(email: string): Promise<User> {
    const user = await this.userModel.findOne({ email: email.toLowerCase() });
    return user;
  }
}
